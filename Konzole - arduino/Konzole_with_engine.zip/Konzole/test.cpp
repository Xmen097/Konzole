#include "define.h"

// 4300 BYTES OF FLASH

#define sample_count 1

namespace test {
  byte test_stage = -1;
  byte last_test_stage = -1;
  byte test_stage_count = 10;
  long test_stage_time = -1;
  long test_stage_step = 0;
  
  int test_stage2_x[] = {55, 160, 55, 85, 25, 55, 260, 260, 235, 285};
  int test_stage2_y[] = {120, 155, 180, 150, 150, 150, 120, 170, 145, 145};
  
  const byte axis[] = {axis_left1, axis_left2, axis_left3, axis_right1, axis_right2, axis_battery};
  
  const __FlashStringHelper *names[6];
  
  int reading = 0;
  char reading_text[4];
  
  void setup() {
    //sys_functions_disabled = true;
    test_stage = 0;
    names[0] = F("L1");
    names[1] = F("L2");
    names[2] = F("L3");
    names[3] = F("R1");
    names[4] = F("R2");
    names[5] = F("BT");
  }

  void basic_test_stage() {
    tft.fillScreen(color_black);
    tft.setCursor(55, 20);
    tft.setTextColor(color_white);
    tft.setTextSize(3);
    tft.println(F("Test konzole"));
    test_stage_time == -1;
    test_stage_step = 0;
  }

  void display_test_stage() {
    switch(test_stage) {
      case 0:
        tft.fillScreen(color_black);
        tft.setCursor(55, 20);
        tft.setTextColor(color_white);
        tft.setTextSize(3);
        tft.println(F("Test konzole"));
        test_stage_time = millis();
        break;
      case 1:
        tft.fillScreen(color_black);
        tft.setCursor(55, 20);
        tft.setTextColor(color_white);
        tft.setTextSize(3);
        tft.println(F("Test konzole"));
        
        tft.setCursor(50, 60);
        tft.setTextSize(2);
        tft.println(F("dolni rada tlacitek"));
        test_stage_time = -1;
        break;
      case 2:
        basic_test_stage();
        tft.setTextSize(1);
        tft.setCursor(250, 220);
        tft.print(F("pokracovat"));
        tft.setCursor(190, 220);
        tft.print(F("osy"));
        tft.setTextSize(2);
        tft.setCursor(70, 60);
        tft.print(F("horni tlacitka"));
        for(int i=0; i<10; i++) {
          tft.fillCircle(test_stage2_x[i], test_stage2_y[i], 15, color_gray);
          tft.fillCircle(test_stage2_x[i], test_stage2_y[i], 12, color_black);
        }
        break;
      case 3:
        basic_test_stage();
        tft.setCursor(270, 220);
        tft.setTextSize(1);
        tft.print(F("zpet"));
        tft.setTextSize(2);
        tft.setCursor(150, 60);
        tft.print(F("osy"));
        for(byte a=0; a<6; a++) {
          tft.setCursor(0, 100+20*a);
          tft.setTextColor(color_white);
          tft.setTextSize(1);
          tft.print(F("Osa "));
          tft.print(names[a]);
          tft.print(F(":"));
        }
        delay(750);
        break;
      case 4:
        basic_test_stage();
        tft.setTextSize(1);
        tft.setCursor(250, 220);
        tft.print(F("vynulovat"));
        tft.setCursor(190, 220);
        tft.print(F("zmenit"));
        tft.setTextSize(2);
        tft.setCursor(120, 60);
        tft.print(F("bzucak"));
        test_stage_step = 25;
        delay(750);
        tone(piezo_pin, 0);
        noTone(piezo_pin);
        break;
    }
  }

  void loop_test_stage() {
    switch(test_stage) {
      case 0:
        if (millis() - test_stage_time > 1000 && test_stage_step == 0) {
          test_stage_step = 1;
          tft.fillRect(50, 140, 40, 40, color_red);
        } else if (millis() - test_stage_time > 2000 && test_stage_step == 1) {
          test_stage_step = 2;
          tft.fillRect(140, 140, 40, 40, color_lime);
        } else if (millis() - test_stage_time > 3000 && test_stage_step == 2) {
          test_stage_step = 3;
          tft.fillRect(230, 140, 40, 40, color_blue);
        } else if(millis() - test_stage_time > 3000 && test_stage_step == 3) {
          test_stage++;
        }
        break;
      case 1:
        for(int i=0; i<bottom_button_count; i++) {
          if (!digitalRead(bottom_button_pins[i]) && button_debounced(i)) {
            if (!(test_stage_step & (1<<(i*2)))) tft.fillCircle(55+70*i, 200, 15, color_gray);
            if (!(test_stage_step & (1<<(1+i*2)))) tft.fillCircle(55+70*i, 200, 12, color_white);
            test_stage_step |= 0b11<<(i*2);
          } else if(digitalRead(bottom_button_pins[i]) && button_debounced(i) && test_stage_step & (1<<(1+i*2))) {
            tft.fillCircle(55+70*i, 200, 12, color_black);
            test_stage_step &= ~(1<<(1+i*2));
          }
        }
        if (test_stage_step == 0b1010101 && test_stage_time == -1)  test_stage_time=millis();
        if (test_stage_time != -1 && millis() - test_stage_time > 2500) test_stage++;
        break;
      case 2:
        for(int i=0; i<10; i++) {
          if (Input::is_pressed(i) && !(test_stage_step & (1<<i))) {
            tft.fillCircle(test_stage2_x[i], test_stage2_y[i], 12, color_white);
            test_stage_step |= 1<<i;
          } else if (!Input::is_pressed(i) && test_stage_step & (1<<i)){
            test_stage_step &= ~(1<<i);
            tft.fillCircle(test_stage2_x[i], test_stage2_y[i], 12, color_black);
          }
        }
        if (!digitalRead(button_bottom3_pin) && button_debounced(2)) test_stage=3;
        if (!digitalRead(button_bottom4_pin) && button_debounced(3)) test_stage=4;
        break;
      case 3: 
        tft.setTextColor(color_white);
        tft.setTextSize(1);
        for(byte a=0; a<6; a++) {
          reading = 0;
          for (byte i=0; i<sample_count; i++ ) {
            reading += analogRead(axis[a]);
          }
          itoa(reading/sample_count,reading_text,10);
          tft.setCursor(50, 100+20*a);
          tft.print(reading_text);
        }
        
        delay(100);
        tft.fillRect(50, 100, 25, 120, color_black);
        if (!digitalRead(button_bottom4_pin) && button_debounced(3)) test_stage=2;
        break;
      case 4:
        if (!digitalRead(button_bottom3_pin) && button_debounced(2)) {
          test_stage_step *= 2;
          delay(500);
          tone(piezo_pin, test_stage_step);
        }
        if (!digitalRead(button_bottom4_pin) && button_debounced(3)) {
          test_stage_step = 25;
          noTone(piezo_pin);
        }
        break;
    }
  }

  void loop() {
    if (last_test_stage != test_stage) {
      last_test_stage = test_stage;
      test_stage_step = 0;
      display_test_stage();
    }
    loop_test_stage();
  }
  
  void destruct() {
    //sys_functions_disabled = false;
  }
  
}
