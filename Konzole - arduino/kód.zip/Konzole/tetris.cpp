#include "define.h"

namespace tetris {
  
  void setup() {
    
  }
  
  void loop() {
    
  }
  
}
